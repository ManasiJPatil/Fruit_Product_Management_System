/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package manufacturing_fruit_product_management_system;

/**
 *
 * @author Admin
 */
public class Manufacturing_fruit_product_management_system {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
