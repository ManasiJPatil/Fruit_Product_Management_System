/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package manufacturing_fruit_product_management_system;

/**
 *
 * @author Admin
 */
public class login_page {
    
}
